My website URL is at https://www.otakuabroadjapan.com/
My website is hosted on Bluehost (using cPanel file manager v3)

Additional Notes: 
- For this submission, I have added back the .html to all anchor tags and action attribute
  for it work locally/from Atom (using "Open in Browser").

- However, in the live website/webhosting url, all the html and 
  php file extensions will be stripped from the url by my .htaccess code.

- Hence, in the live website source code, the anchor tags and 
  action attribute will not have any extension behind it
  (E.g. <a href="AnimeRecommend">Anime</a>).

- If needed, the original files for the hosted/live website is on github,
  https://github.com/KJHJason/OtakuAbroadJapan-Website

- Thank you!