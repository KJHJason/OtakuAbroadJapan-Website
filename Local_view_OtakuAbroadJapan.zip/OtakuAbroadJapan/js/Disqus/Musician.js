// JavaScript provided by Disqus just that I had to learn how to edit the code to use it on my page through reading their documentation
var disqus_config = function () {
this.page.url = 'https://www.otakuabroadjapan.com/blogs/sub/Musician';
this.page.identifier = "000006";
};

(function() { // DON'T EDIT BELOW THIS LINE
var d = document, s = d.createElement('script');
s.src = 'https://otakuabroadjapan.disqus.com/embed.js';
s.setAttribute('data-timestamp', +new Date());
(d.head || d.body).appendChild(s);
})();
